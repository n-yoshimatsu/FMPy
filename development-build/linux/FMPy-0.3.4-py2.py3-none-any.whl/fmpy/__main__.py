
if __name__ == '__main__':
    from fmpy.command_line import main
    main()
